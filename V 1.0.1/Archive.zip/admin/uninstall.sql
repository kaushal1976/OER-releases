DROP TABLE IF EXISTS `#__oer_oers`;
DROP TABLE IF EXISTS `#__oer_languages`;
DROP TABLE IF EXISTS `#__oer_licenses`;